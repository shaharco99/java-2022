
/**
 * Write a description of class RectangleA here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class RectangleA
{
    private int _width;
    private int _height; 
    private String _pointSW;
    public RectangleA (int w, int h){
        _width=w;
        _height=h;
        _pointSW= "(0,0)";
    }  
    // public int getWidth(){
        // return _width;
    // }
    // public int getHeight(){
        // return _height;
    // }
    // public void setW (int numW) {
        // _width=numW;
    // }
    // public void setH (int numH) {
        // _height=numH;
    // }
    
}
