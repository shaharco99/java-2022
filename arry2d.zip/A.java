
/**
 * Write a description of class A here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class A
{
    private int _x;
    private double _y;
    
    public A(int x, double y) {
        _x = x;
        _y = y;
    }
    
    public A(int x) {
        this(x, 5.0);
    }
    
    public A() {};
}



















