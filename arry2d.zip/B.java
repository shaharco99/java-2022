
/**
 * Write a description of class B here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class B extends A
{
    private int _m; 
    public B(int m) {
        super(7);
        _m = m;
    }
}
